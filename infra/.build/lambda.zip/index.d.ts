interface ApiResponse {
    statusCode: number;
    headers: Record<string, string>;
    body: string;
}
interface LambdaEvent {
    requestContext: {
        http: {
            method: string;
            path: string;
        };
    };
    body?: string;
}
export declare function handler(event: LambdaEvent): Promise<ApiResponse>;
export {};
//# sourceMappingURL=index.d.ts.map