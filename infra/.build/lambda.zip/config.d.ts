export declare const CONFIG: {
    TABLE_NAME: string;
    REGION: string;
    ENDPOINT_URL: string | undefined;
    API_ORIGIN: string;
    VALIDATION: {
        NAME_MIN: number;
        NAME_MAX: number;
        EMAIL_PATTERN: RegExp;
        MESSAGE_MIN: number;
        MESSAGE_MAX: number;
    };
};
//# sourceMappingURL=config.d.ts.map